package main;


public class Main {



	public static void main(String[] args) {
		
		int max = 1000000000;
		
		Fibonacci f = new Fibonacci(max);
		
		System.out.println(String.format("il primo numero maggiore di %s della sequenza di fibonacci � %s",max, f.getLastElement()));
		System.out.println(String.format("il primo numero maggiore di %s della sequenza di fibonacci � alla %sa posizione",max, f.getLunghezzaSequenza()));
		f.printSequenza();
		
		
	}


}
